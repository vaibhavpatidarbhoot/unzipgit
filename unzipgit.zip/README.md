# unzipgit
<img src="https://github.com/unzipgit/unzipgit.github.io/raw/main/images/unzippriview.png" width="1000" />

website: [unzipgit.github.io](https://unzipgit.github.io)
--- 
- With unzipgit, you can unzip a .zip archive to your GitHub repository. Unzipgit uses the jszip library and the GitHub API, which means that all actions take place on the client side (your browser).

- If you want to unzip the archive to some folder, specify «yourrepo/folder» in the «repository» field.

- You can unzip an archive that is already in the repository, or you can download the archive from your device.

- If you are unzipping an archive that is already in the repository but stored in a specific folder, you can specify the full path «folder/archive.zip» in the «archive in repo» field.
***
